package main

import "github.com/anilmisirlioglu/Tic-Tac-Toe-AI/game"

func main() {
	game := game.NewGame()
	game.Start()
}
